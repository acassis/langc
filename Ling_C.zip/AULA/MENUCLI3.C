#include <stdio.h>
#include <conio.h>
#include <graphics.h>
#include "menucli2.c"
void main(void)
{
  char *m[]={"INCLUSAO","consulta","sair"};
  menu(10,10,m);
}