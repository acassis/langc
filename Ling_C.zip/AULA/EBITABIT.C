deslocamento a direita
a)10 - 1   b)100 -2   c)80 - 2   d)70 - 3  e)50 - 3  f)90 - 4
deslocamento a esquerda
a)10 - 1   b)100 -2   c)80 - 2   d)70 - 3  e)50 - 3  f)90 - 4
operador &
a)3 - 3   b)2 - 1   c)5 - 2   d)7 - 3  e)f - 3  f)9 - 1
operador |
a)3 - 3   b)2 - 1   c)5 - 2   d)7 - 3  e)f - 3  f)9 - 1
operador ^
a)3 - 3   b)2 - 1   c)5 - 2   d)7 - 3  e)f - 3  f)9 - 1
complemento ~
a)3  b)2  c)5  d)7  e)f  f)9 g)e  h)15  i)a  j)1  l)c  m)ff  n)13  o)11