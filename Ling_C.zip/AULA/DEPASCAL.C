

#define begin main(){
#define write(x) printf("\n");printf(x)
#define end }

begin
write("isto � um programa em c com comandos de pascal");
end