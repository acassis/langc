#include<graphics.h>
#include<conio.h>
char a;
main()
{
 line(1,1,100,100);
 a=getch;
}