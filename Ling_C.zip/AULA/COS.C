#include <stdio.h>
#include <math.h>
 int main(void)
 {
    double result;
    double x = 60;

    result = cosh(x);
    printf("\nThe cosine of %lf is %lf\n", x, result);
    return 0;
 }

