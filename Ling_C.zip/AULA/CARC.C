#include <stdio.h>
#include <conio.h>
#include <dos.h>

main()
{
 int c;
 clrscr();
 c=getche();
 printf("%d",c);
}