#include <stdio.h>
#include <conio.h>
void main(int argc,char **argv)
{
 while(*argv)
      printf("%s ",*argv++);
}