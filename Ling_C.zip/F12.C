main ()
{
 int i=0,val=0;
 clrscr();
 puts ("entre com o valor inicial:");
 scanf("%d",&val);
 for (i=val;i<=100;i++)
     printf("%d\n",i);
}