#include<conio.h>
void main()
{
_setcursortype(0);
}