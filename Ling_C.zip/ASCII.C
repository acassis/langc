#include<stdio.h>
#include<conio.h>
main()
{
 int i=0;
 while(i<255){
 clrscr();
 printf("\n %c = %d",i,i);
 i++;
 getch();}
}