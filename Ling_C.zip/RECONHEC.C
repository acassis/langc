void main(void)
{
 char ch=0;
 clrscr();
 while (ch!='.')
 {
   ch=getche();
  printf("        %d\n",ch);
 }
}