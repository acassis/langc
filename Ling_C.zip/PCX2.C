#include "d:\bc\include\pcx.h"
void main()
{
    ReadPCX( "d:\\bc\\ling_c\\pcx\\casal.pcx" ,0,0);
}