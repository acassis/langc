main()
{
 int inicio, fim;
 puts("informe o inicio e o fim");
 scanf("%d",&inicio);
 scanf("%d",&fim);
 for(;inicio<=fim;inicio++)
     printf("%d\n",inicio);
 puts ("fim");
 }
