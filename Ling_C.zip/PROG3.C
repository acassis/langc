main()
{
 int inicio, fim;
 puts("informe o inicio e o fim");
 scanf("%d",&inicio);
 scanf("%d",&fim);
 for(;inicio<=fim;inicio++)
     if ((inicio%2)==0)
	printf("%d"),inicio);
 puts ("fim");
 }
