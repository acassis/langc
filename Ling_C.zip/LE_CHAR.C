#include<conio.h>
#include<stdio.h>
void main()
{
  clrscr();
  printf("%d",getch());
}