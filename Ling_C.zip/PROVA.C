void main (void)
{
 int i=0,f=0,m=0;
 clrscr();
 puts("entre com um o inicio");
 scanf("%d",&i);
 puts ("entre com o fim");
 scanf("%d",&f);
 for(i>f;i>f;i--)
     printf("%d\n",i);
 for (i<f;i<=f;i++)
     printf("%d\n",i);
}