#include <stdlib.h>
#include <stdio.h>
void main()
{
   char faz[]="copy este.exe c:\\este.exe";
   clrscr();
   system(faz); //
}