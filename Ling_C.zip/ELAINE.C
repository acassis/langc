void main()
{
   char nome[]="elaine";
   clrscr();
   printf("%s",nome);
   getch();
}