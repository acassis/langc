void main (void)
{
 int x=12,*p=&x;
 clrscr();
 printf("%d\n",x);
 *p=35;
 printf("%d",x);
}
